import aside from "./aside.js";
import chat from "./chat.js";
window.addEventListener("DOMContentLoaded", function(){
    aside();
    chat();
});